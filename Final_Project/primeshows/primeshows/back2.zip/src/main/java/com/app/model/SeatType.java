package com.app.model;

public enum SeatType {
    REGULAR, PREMIUM, VIP
}
