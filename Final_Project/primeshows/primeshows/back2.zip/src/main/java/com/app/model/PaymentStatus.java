package com.app.model;

public enum PaymentStatus {
    SUCCESS, 
    PENDING, 
    FAILED,REFUNDED
}
