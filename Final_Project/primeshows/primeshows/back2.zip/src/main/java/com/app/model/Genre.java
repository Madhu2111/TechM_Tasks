package com.app.model;

public enum Genre {
    ACTION, DRAMA, COMEDY, HORROR, ROMANCE, THRILLER, SCI_FI, ANIMATION, DOCUMENTARY
}
