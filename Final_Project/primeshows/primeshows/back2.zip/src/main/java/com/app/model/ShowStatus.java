package com.app.model;

public enum ShowStatus {
    ACTIVE, CANCELLED, COMPLETED
}
