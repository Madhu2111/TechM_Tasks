package com.app.model;

public enum BookingStatus {
    CONFIRMED, CANCELLED, PENDING,REFUNDED
}
